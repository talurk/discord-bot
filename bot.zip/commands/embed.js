const Discord = require('discord.js')

module.exports = {
    run: message => {
        message.channel.send(new Discord.MessageEmbed()
            .setTitle('**Embed**')
            .setDescription('Veuillez vous adressez à @talurk0001 pour plus d\'informations.')
            .setColor('#0800FF')
            .setTimestamp())
    },
    name: 'embed'
}
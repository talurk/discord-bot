module.exports = {
    run: message => message.channel.send('**Arrête ou je te tue**'),
    name: 'stop',
    help: {
        description: 'Faites taire la personne en face de vous'
    }
    
}
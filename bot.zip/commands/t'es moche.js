module.exports = {
    run: message => message.channel.send('|| t\'es moche ||'),
    name: 'oof',
    help:{
        description: 'Montrer à quelle point cette personne est moche.'
    }
}
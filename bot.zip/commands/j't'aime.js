module.exports = {
    run: message => message.channel.send('|| j\'t\aime le s ||'),
    name: 'bis',
    help: {
        description: 'Décrivez votre amour à l\'autre !'
    }
}